# 本地部署 Agent 自进化型记忆系统 · 设计文档
**赛道方向**：第四届全国翻译技术大赛 · 智能体和技能（Skills）创新设计赛道 · OpenClaw 创新挑战方向

---

## 一、系统概述

本系统是一个**本地可直接部署**、面向 Agent 的**自进化型记忆系统**。它让 Agent 在本地拥有长期、结构化、可自我优化的记忆能力，而不依赖云端大模型或外部数据库。

**核心特性**
- 本地优先：全部记忆存于本地文件系统，离线可用、数据自持。
- 模块化存储：记忆按知识类型拆分为独立 skill 文件，分级索引。
- 自进化：依据使用频率与用户反馈自动调优优先级，淘汰低价值记忆。
- 安全可靠：本地加密、指令需授权、防提示注入。

**适用场景**：个人助手、翻译 Agent、领域知识 Agent 等需要"记住用户偏好/事实/指令"并随使用不断精炼的长期记忆场景。

---

## 二、系统架构

### 2.1 三级存储架构

系统采用 **"系统总库 → 分类 skill 库 → 记忆条目"** 三级结构：

- **系统总库（Meta Index）**：全局索引层，记录所有分类库的元信息与跨类检索入口。
- **分类 skill 库（Category Skill）**：按知识类型划分的独立 skill 文件集合（常识 / 指令 / 偏好 / 事实…），每个分类一个 skill。
- **记忆条目（Memory Entry）**：单条记忆的最小存储单元，落到对应分类 skill 库内。

### 2.2 架构图

```mermaid
flowchart TB
    U[用户输入 / Agent 调用] --> IC[① 信息核对模块]
    IC -->|有效且去重| MS[② 记忆存储模块]
    IC -->|无效/重复| REJ[拒绝并记录日志]
    MS --> RT[⑤ 模块化路由]
    RT -->|按 type 路由| CS1[分类库:常识]
    RT --> CS2[分类库:指令]
    RT --> CS3[分类库:偏好]
    RT --> CS4[分类库:事实]
    CS1 & CS2 & CS3 & CS4 --> ME[(记忆条目文件)]
    MS --> MI[系统总库索引]
    MI -.元数据同步.-> CS1 & CS2 & CS3 & CS4

    U2[检索请求] --> KT[⑦ 智能化知识调动]
    KT --> MI
    MI -->|先总库| KT
    KT -->|再分类库| CS1 & CS2 & CS3 & CS4
    KT --> OUT[按相关性排序返回]

    CM[⑥ 自进化更新] -->|调优先级/淘汰| CS1 & CS2 & CS3 & CS4
    CM -->|冲突检测| CT[③ 矛盾剔除 + ④ 更新询问]
    CT --> U3[用户确认保留策略]
```

### 2.3 模块组成
共 7 个核心功能模块 + 1 个索引/路由层（系统总库），详见第三章。

---

## 三、核心功能模块详述

### ① 信息核对（Input Validation）
- **触发**：识别用户"记住 …"类指令或 Agent 显式写入调用。
- **行为**：
  1. 完整性校验：必填语义缺失（如空内容、无明确主体）则拒绝并提示补全。
  2. 有效性校验：过滤无意义、纯噪声、格式损坏的内容。
  3. 去重：与现有记忆做相似度比对（关键词 + 语义向量），重复则合并或跳过。
- **输出**：通过校验的记忆进入存储流程；未通过进入拒绝日志。

### ② 记忆存储（Memory Persistence）
- 每条记忆初始化为**独立 skill 文件**（单文件单条目，便于增删与版本管理）。
- 写入时填充标准数据结构（见第四章），默认 `status=active`、`priority` 由初始置信度推导。

### ③ 矛盾剔除（Conflict Detection）
- 新记忆入库前，与同类型分类库内已有条目做**逻辑冲突检测**（矛盾陈述、互斥值、时效冲突）。
- 命中冲突：不自动处置，转交 ④ 更新询问，由用户确认后执行**保留 / 删除 / 合并**。

### ④ 更新询问（Clarification Ask）
- 检测到冲突或低置信度时，**主动向用户发起询问**，呈现冲突双方内容与来源。
- 由用户决定保留策略，系统仅执行，不替用户臆断（遵循人类拍板原则）。

### ⑤ 模块化记忆存储（Modular Routing）
- 按知识类型自动分类：`常识 / 指令 / 偏好 / 事实`（可扩展）。
- 每条记忆路由到对应分类 skill 库，并在系统总库建立**多级索引**（type → skill → entry_id）。
- 分类规则可配置；未命中已知类型时归入 `其他` 并提示用户标注。

### ⑥ 自进化记忆更新（Self-Evolution）
- **触发条件**：
  - 每次检索后 `access_count +1`，刷新 `last_accessed`；
  - 用户显式反馈（纠正 / 确认 / 点赞）；
  - 定时扫描任务（默认每日低峰期）评估陈旧度。
- **执行流程**：
  1. 计算优先级 `priority = w1·频次归一 + w2·时效衰减 + w3·反馈权重`；
  2. `priority` 低于阈值且长期未访问 → 标记 `status=deprecated`；
  3. 淘汰窗口内未被复用 → 移入归档或物理删除（可配置保留策略）。
- **目标**：持续抬高高价值记忆的检索命中率，压缩噪声。

### ⑦ 智能化知识调动（Graded Retrieval）
- **分级调用逻辑**：
  1. **先检索系统总库**（全局索引，快速定位候选分类）；
  2. **再检索下属各分类 skill 库**（深入候选分类取条目）；
  3. 汇总后按 **相关性 = 语义相似度 × priority × 时效** 排序返回 Top-K。
- 高层级（总库命中、强相关）结果优先呈现。

---

## 四、数据结构定义

### 4.1 记忆条目（Memory Entry）
每条记忆存为一个 JSON / skill 文件，标准字段如下：

| 字段 | 类型 | 说明 |
|---|---|---|
| `id` | string | 全局唯一标识，如 `mem_20260708_a1b2` |
| `type` | enum | 知识类型：`common_sense` / `instruction` / `preference` / `fact` / `other` |
| `content` | string | 记忆原文 / 结构化文本 |
| `confidence` | float[0,1] | 初始置信度，由核对模块赋予 |
| `source` | string | 来源：`user_input` / `inferred` / `imported` |
| `timestamp` | datetime(ISO8601) | 创建时间 |
| `access_count` | int | 被检索/调用次数（支撑自进化） |
| `priority` | float[0,1] | 动态优先级，由自进化模块维护（扩展字段） |
| `status` | enum | `active` / `deprecated`（扩展字段） |
| `last_accessed` | datetime | 最近访问时间（扩展字段，支撑时效衰减） |

> 标注"扩展字段"的 3 项为支撑自进化机制而增设，原提示词 7 字段为基础集。

**示例：**
```json
{
  "id": "mem_20260708_a1b2",
  "type": "preference",
  "content": "用户偏好中文技术文档，术语统一用简体",
  "confidence": 0.9,
  "source": "user_input",
  "timestamp": "2026-07-08T20:00:00+08:00",
  "access_count": 12,
  "priority": 0.82,
  "status": "active",
  "last_accessed": "2026-07-08T20:10:00+08:00"
}
```

### 4.2 分类 skill 库（Category Skill）
- 每个分类一个 skill 目录，内含该分类下全部记忆条目文件 + 一个 `index.json`（本类索引与向量缓存）。
- 目录约定：`<agent>/memory/<type>/`。

### 4.3 系统总库（Meta Index）
- 单文件 `meta_index.json`，结构：`{ categories: [{type, path, entry_count, updated_at}], global_vectors: [...] }`。
- 负责跨类检索入口与分级调用第一跳。

---

## 五、模块间交互关系

### 5.1 写入流程
```mermaid
sequenceDiagram
    participant U as 用户/Agent
    participant IC as 信息核对
    participant MS as 记忆存储
    participant RT as 模块化路由
    participant CS as 分类库
    participant MI as 系统总库
    U->>IC: 记住 X
    IC-->>U: 校验(完整/有效/去重)
    IC->>MS: 通过
    MS->>RT: 按 type 路由
    RT->>CS: 写入条目文件
    RT->>MI: 同步索引
    MS->>CT: 入库前冲突检测
    CT->>U: 冲突则询问
    U->>CT: 确认保留策略
```

### 5.2 检索流程
```mermaid
flowchart LR
    Q[检索请求] --> KT[知识调动]
    KT --> MI[系统总库:定位候选分类]
    MI --> CS[分类库:取条目]
    CS --> S[相关性排序 priority×相似度×时效]
    S --> R[返回 Top-K]
    R --> EV[自进化:access_count+1]
```

### 5.3 冲突处理流程
新记忆 → 矛盾剔除比对 → 有冲突 → 更新询问 → 用户拍板（保留/删除/合并）→ 写回对应库与总库索引。

---

## 六、安装部署流程

### 6.1 环境要求
- 操作系统：Windows 10+（亦支持 macOS / Linux）；
- 运行时：Python 3.10+（或已编译的 agent 宿主环境）；
- 依赖：本地向量检索库（如 `chromadb` / `faiss` 轻量版，可选）、文件加密库（如 `cryptography`）。

### 6.2 源码获取
- GitHub：`git clone https://github.com/<your-org>/openclaw-memory.git`
- Gitee：`git clone https://gitee.com/<your-org>/openclaw-memory.git`

### 6.3 安装（一键）
- **Windows（CMD / 双击）**：执行仓库根目录 `install.bat`，自动将记忆系统挂载到 agent 的记忆插件目录。
- **跨平台**：`python setup.py install`（或 `pip install -e .`），按提示选择目标 agent 路径。
- 安装后**即插即用**，无需额外配置；首次运行自动初始化 `meta_index.json` 与分类目录。

### 6.4 部署目录结构
```
<agent>/
└─ memory/
   ├─ meta_index.json        # 系统总库
   ├─ common_sense/          # 分类 skill 库
   ├─ instruction/
   ├─ preference/
   ├─ fact/
   └─ other/
```

---

## 七、性能与安全要求

### 7.1 性能
- 单次检索响应 **< 200ms**（万级条目规模下不降级）；
- 写入延迟 < 100ms / 条；
- 自进化定时扫描在空闲窗口执行，不阻塞主链路。

### 7.2 安全
- **本地加密**：记忆文件落地前经用户密钥加密，防止本地明文泄露；
- **指令授权**：任何"删除 / 覆盖 / 批量操作"类指令需用户显式授权，系统不擅自处置；
- **防提示注入**：记忆内容在召回与拼接时做注入隔离（不把记忆原文当作可执行指令），避免被恶意记忆劫持 Agent。

---

## 八、总结

本设计以"本地、模块化、自进化"为主线，用三级存储（总库→分类库→条目）实现清晰的数据边界，用 7 大模块覆盖从**写入校验、冲突治理、分类路由到检索调动**的完整闭环，并以**使用频率 + 用户反馈**双驱动实现记忆的持续自优化。安装零配置、数据自持、安全可控，适合作为 OpenClaw 挑战方向下的本地 Agent 记忆基座提交。
