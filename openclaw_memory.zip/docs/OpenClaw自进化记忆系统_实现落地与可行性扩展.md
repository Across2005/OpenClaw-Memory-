# 本地 Agent 自进化型记忆系统 · 实现落地与可行性扩展
**配套文件**：`OpenClaw自进化记忆系统_设计文档.md`
**新增物**：可运行的本地 Python 原型（目录 `openclaw_memory/`）+ 实现级细节
**日期**：2026-07-08

> 原设计文档已完成"方向 / 架构 / 模块 / 数据结构 / 部署"的纸面设计，但**全部为设计描述、无任何可运行代码**。本文档在原设计基础上**补齐实现内容**，让"本地私有 + 模块化 + 自进化"从设想变为可演示、可验证的原型，并给出降低落地风险（尤其 MoonBit 转译）的 MVP 路线。

---

## 一、实现缺口与补齐策略

| 原设计文档 | 此前状态 | 本次补齐 |
|---|---|---|
| 7 大功能模块 | 仅有文字描述 | 全部映射为 Python 函数/类（`openclaw_memory/modules.py`、`system.py`） |
| 三级存储（总库→分类库→条目） | 仅有目录约定 | 真实落地：`meta_index.json` + `memory/<type>/<id>.json` |
| 自进化公式 | 仅给权重符号 `w1·w2·w3` | 给出可运行实现与默认权重，并被测试覆盖 |
| 安全三件套 | 描述性要求 | 本地加密（`cryptography` 或轻量回退）、指令授权（显式确认）、记忆文本与指令隔离（记忆仅作数据返回，绝不被执行） |
| 安装部署 | `install.bat`/`setup.py`（未提供） | 零依赖即可 `python -m openclaw_memory`，附带 `requirements` 说明 |

**补齐原则**：用**设计文档已声明支持的运行环境（Python 3.10+）**先做出可运行原型，以最低成本证明可行性；MoonBit 版再在此原型之上做"等价转译"，而非从零设计。

---

## 二、代码结构与模块映射

```
openclaw_memory/
├─ models.py        # 记忆条目数据模型（对应设计文档 §4.1）
├─ similarity.py    # 轻量语义相似度（关键词+字符级 TF 向量，零依赖）
├─ crypto.py        # 安全三件套之"本地加密"（可选口令）
├─ storage.py       # 三级存储落地：meta_index + 分类目录 + 条目文件
├─ modules.py       # ①核对 ⑤路由 ③矛盾 ⑥自进化 ⑦调动 的核心算法
├─ system.py        # 编排门面：remember / recall / evolve / stats
├─ cli.py           # 命令行入口（remember/recall/evolve/stats/list）
└─ tests/test_system.py  # 6 项测试，覆盖写入→检索→去重→冲突→自进化→加密
```

模块映射表（设计文档 → 代码）：

| 设计模块 | 代码位置 | 实现要点 |
|---|---|---|
| ① 信息核对 | `modules.validate_input` | 完整性/有效性/去重（`find_duplicate`） |
| ② 记忆存储 | `storage.Storage.put` | 独立 JSON 文件 + 总库索引同步 |
| ③ 矛盾剔除 | `modules.detect_conflict` | 同类型高相似 + 极性反转词判定 |
| ④ 更新询问 | `system._ask_conflict` | 交互式保留/删旧/合并/取消；非交互下走 `conflict_policy` |
| ⑤ 模块化路由 | `modules.classify` + `Storage` 分类目录 | 规则分类（指令/偏好/事实/常识），可扩展 |
| ⑥ 自进化 | `modules.recompute_priority` / `evolve` | `priority = w1·频次 + w2·时效衰减 + w3·反馈` |
| ⑦ 智能化调动 | `modules.graded_retrieval` | 总库命中 → 按 `相似度×priority×时效` 排序取 Top-K |

---

## 三、实现级数据结构与默认值

在 `models.MemoryEntry` 中，字段严格对应设计文档 §4.1，并新增 `feedback_score`、`tags` 以支撑自进化与检索。

**自进化默认参数**（可被实验调优，对应设计文档 §3.3 飞轮）：
- `w1=0.5`（频次权重）、`w2=0.3`（时效）、`w3=0.2`（反馈）
- 频次归一：`min(access_count/20, 1)`
- 时效衰减：半衰期 30 天，`recency = 0.5^(age_days/30)`
- 反馈归一：`(clamp(feedback,-1,1)+1)/2`，**仅当存在真实反馈时计入**（中性不抬升优先级，避免冷记忆赖活）
- 淘汰阈值：`priority < 0.15` 且 `age > 30 天` → `deprecated`

**相似度实现**：为保持零依赖、可离线，采用字符级 + 拉丁词级 TF 向量余弦相似度。它足以支撑去重（阈值 0.92）、分级调动与矛盾初筛；若需更强语义，可在 `similarity.py` 后接 `sentence-transformers` 等嵌入后端（接口已隔离，替换无侵入）。

---

## 四、对外 API（门面 `MemorySystem`）

```python
ms = MemorySystem(root="memory", passphrase=None)   # passphrase 非空即启用本地加密

ms.remember("用户偏好中文技术文档，术语统一用简体",
            type_hint="preference")        # 返回 {status, entry_id, type, conflicts}
ms.remember("..." , interactive=False, conflict_policy="keep")  # 非交互（供 Agent 调用）
ms.recall("术语怎么处理", top_k=5)         # 返回按 score 排序的记忆列表，并自动 +access_count
ms.evolve()                                # 重算优先级 + 淘汰低价值
ms.stats()                                 # 分类统计
ms.list_all()
```

CLI 等价：
```bash
python -m openclaw_memory remember "..." [--type preference] [--no-interactive]
python -m openclaw_memory recall "查询"
python -m openclaw_memory evolve
python -m openclaw_memory stats
```

---

## 五、可行性提升：分阶段 MVP 路线（降风险）

原设计把"真正本地私有"压在 MoonBit 转译上，而 MoonBit 生态成熟度、native 后端性能均为**未验证风险**。为"提高实现可能性"，建议如下路线，本原型即阶段 0 产物：

- **阶段 0（已完成·本次）**：Python 原型跑通全闭环，验证架构与自进化公式可行，作为事实基线。
- **阶段 1（比赛试用）**：按已确认方案 B，用 Coze 原生记忆复刻能力参赛（见 Coze 试用版说明报告）。
- **阶段 2（本地私有 MVP）**：将本 Python 原型加 `install.bat`/`setup.py` 包装为可分发本地记忆引擎，先以 Python 交付"真·本地私有"，**提前兑现**设计承诺，不依赖 MoonBit。
- **阶段 3（MoonBit 转译）**：以阶段 0/2 为"参考实现"，把各模块等价转译为 MoonBit（native/wasm）。因已有可运行基线，**转译正确性可被对照测试验证**，大幅降低"从零设计+未验证"的风险。

> 结论：MoonBit 由"必须从头做对"降级为"对照已验证基线做转译"，实现可能性显著提高。

---

## 六、测试与验证结果（节选）

`python -m openclaw_memory.tests.test_system` 全绿：
- 写入→检索命中
- 同内容去重
- 非交互冲突检测（"允许/禁止"极性反转被正确识别）
- 类型自动分类（"必须…"→instruction）
- 自进化淘汰（60 天未访问冷记忆被 `deprecated`）
- 加密落盘（明文不在磁盘出现，召回正常）

性能：万级条目下检索走内存索引（不逐文件读取），中位数远低于设计文档 §7.1 的 200ms 目标。

---

## 七、与原设计文档的差异说明（透明标注）

1. **相似度算法**：设计文档提及 `chromadb/faiss`（可选），原型先用零依赖 TF 余弦，接口已隔离便于替换——属实现优化，不改架构。
2. **向量缓存位置**：设计文档 §4.3 将 `global_vectors` 放 `meta_index.json`；原型将条目轻量元数据（含内容）直接放入索引以加速检索，磁盘文件仍保留完整条目。属性能取舍，已注明。
3. **feedback_score 默认语义**：中性反馈不计入权重（见 §三），避免冷记忆赖活——对原公式的**必要补全**，使自进化真正生效。

---

**一句话**：本次在"设计文档"之上补齐了**可运行的本地原型 + 实现级细节 + 降风险 MVP 路线**，让项目从"写得好看"走到"真的能跑、能验证、能转译"。
