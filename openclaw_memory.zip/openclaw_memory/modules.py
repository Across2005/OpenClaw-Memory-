import datetime as _dt
import math
from typing import Optional

from .models import MemoryEntry, MemoryType, MemoryStatus
from .similarity import similarity

_TYPE_KEYWORDS = {
    MemoryType.INSTRUCTION: ["必须", "不要", "禁止", "总是", "务必", "指令", "规则", "不允许", "要求", "应当"],
    MemoryType.PREFERENCE: ["偏好", "喜欢", "习惯", "倾向", "更愿意", "风格", "口味"],
    MemoryType.FACT: ["成立于", "位于", "定义", "数据", "统计", "出生于", "总部", "发布于", "创始于"],
}

_POLARITY = [
    ("支持", "反对"),
    ("是", "不是"),
    ("允许", "禁止"),
    ("喜欢", "讨厌"),
    ("正确", "错误"),
    ("启用", "禁用"),
]


def validate_input(content: str) -> tuple[bool, str]:
    if not content or not content.strip():
        return False, "内容为空"
    cleaned = content.strip()
    if len(cleaned) < 4:
        return False, "内容过短，缺少明确主体"
    if all(ch in "，。、！？. ,!?" for ch in cleaned):
        return False, "内容为纯标点噪声"
    return True, ""


def classify(content: str) -> MemoryType:
    scores = {t: 0 for t in MemoryType}
    for t, kws in _TYPE_KEYWORDS.items():
        for kw in kws:
            if kw in content:
                scores[t] += 1
    best = max(scores, key=lambda k: scores[k])
    if scores[best] == 0:
        return MemoryType.COMMON_SENSE
    return best


def find_duplicate(content: str, candidates: list[MemoryEntry], threshold: float = 0.92) -> Optional[MemoryEntry]:
    best = None
    best_sim = 0.0
    for c in candidates:
        s = similarity(content, c.content)
        if s > best_sim:
            best_sim, best = s, c
    return best if best_sim >= threshold else None


def detect_conflict(new_entry: MemoryEntry, candidates: list[MemoryEntry],
                    threshold: float = 0.55) -> list[MemoryEntry]:
    conflicts = []
    for c in candidates:
        if c.id == new_entry.id:
            continue
        sim = similarity(new_entry.content, c.content)
        if sim < threshold:
            continue
        if _has_opposite_polarity(new_entry.content, c.content):
            conflicts.append(c)
    return conflicts


def _has_opposite_polarity(a: str, b: str) -> bool:
    for pos, neg in _POLARITY:
        if (pos in a and neg in b) or (neg in a and pos in b):
            return True
    return False


def _age_days(iso: Optional[str], now: _dt.datetime) -> float:
    if not iso:
        return 9999.0
    try:
        ts = _dt.datetime.fromisoformat(iso)
        if ts.tzinfo is None:
            ts = ts.replace(tzinfo=_dt.timezone.utc)
        return max((now - ts).total_seconds() / 86400.0, 0.0)
    except Exception:
        return 9999.0


def recompute_priority(entry: MemoryEntry, now: _dt.datetime,
                       w=(0.5, 0.3, 0.2), half_life: float = 30.0) -> float:
    w1, w2, w3 = w
    freq_norm = min(entry.access_count / 20.0, 1.0)
    age = _age_days(entry.last_accessed, now)
    recency = 0.5 ** (age / half_life)
    feedback_norm = 0.0
    if entry.feedback_score != 0.0:
        feedback_norm = (max(-1.0, min(1.0, entry.feedback_score)) + 1.0) / 2.0
    return round(w1 * freq_norm + w2 * recency + w3 * feedback_norm, 4)


def evolve(storage, now: Optional[_dt.datetime] = None,
           deprecate_below: float = 0.15, deprecate_age: float = 30.0) -> dict:
    now = now or _dt.datetime.now(_dt.timezone.utc)
    changed = 0
    deprecated = 0
    for entry in storage.all_entries():
        if entry.status == MemoryStatus.ARCHIVED.value:
            continue
        entry.priority = recompute_priority(entry, now)
        age = _age_days(entry.last_accessed, now)
        if entry.priority < deprecate_below and age > deprecate_age:
            entry.status = MemoryStatus.DEPRECATED.value
            deprecated += 1
        storage.put(entry)
        changed += 1
    return {"recomputed": changed, "deprecated": deprecated}


def graded_retrieval(storage, query: str, top_k: int = 5,
                     now: Optional[_dt.datetime] = None) -> list[tuple[MemoryEntry, float]]:
    now = now or _dt.datetime.now(_dt.timezone.utc)
    results = []
    for entry in storage.all_entries():
        if entry.status != MemoryStatus.ACTIVE.value:
            continue
        sim = similarity(query, entry.content)
        if sim <= 0.0:
            continue
        age = _age_days(entry.last_accessed, now)
        recency = 0.5 ** (age / 30.0)
        score = sim * entry.priority * (0.5 + 0.5 * recency)
        results.append((entry, round(score, 4)))
    results.sort(key=lambda x: x[1], reverse=True)
    return results[:top_k]
