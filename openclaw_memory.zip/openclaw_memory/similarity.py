import re
from collections import Counter

_STOPWORDS = set("的 了 是 在 和 与 及 对 把 被 我 你 他 她 它 们 这 那 有 个 不 也 都 就 而 等 以 为 其 此".split())


def tokenize(text: str) -> list[str]:
    text = text.lower()
    latin = re.findall(r"[a-z0-9]+", text)
    cjk = re.findall(r"[\u4e00-\u9fff]", text)
    tokens = [t for t in latin if t not in _STOPWORDS]
    tokens.extend(cjk)
    return tokens


def embed(text: str) -> Counter:
    return Counter(tokenize(text))


def cosine(a: Counter, b: Counter) -> float:
    if not a or not b:
        return 0.0
    common = set(a) & set(b)
    if not common:
        return 0.0
    dot = sum(a[t] * b[t] for t in common)
    na = sum(v * v for v in a.values()) ** 0.5
    nb = sum(v * v for v in b.values()) ** 0.5
    if na == 0 or nb == 0:
        return 0.0
    return dot / (na * nb)


def similarity(text_a: str, text_b: str) -> float:
    return cosine(embed(text_a), embed(text_b))
