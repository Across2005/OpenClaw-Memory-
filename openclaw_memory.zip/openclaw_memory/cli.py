import argparse
import json
import os
import sys

from .system import MemorySystem


def _system(args) -> MemorySystem:
    root = args.root or os.environ.get("OPENCLAW_MEMORY_ROOT", os.path.join(os.getcwd(), "memory"))
    return MemorySystem(root, passphrase=args.passphrase)


def main(argv=None):
    parser = argparse.ArgumentParser(description="OpenClaw 本地自进化记忆系统 (CLI)")
    parser.add_argument("--root", help="记忆存储根目录")
    parser.add_argument("--passphrase", help="本地加密口令（可选）")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("remember", help="写入一条记忆")
    p.add_argument("content", help="记忆内容")
    p.add_argument("--type", default=None, help="类型: common_sense/instruction/preference/fact/other")
    p.add_argument("--source", default="user_input")
    p.add_argument("--no-interactive", action="store_true")

    p = sub.add_parser("recall", help="检索记忆")
    p.add_argument("query", help="查询内容")
    p.add_argument("--top-k", type=int, default=5)

    sub.add_parser("evolve", help="执行自进化（重算优先级/淘汰）")
    sub.add_parser("stats", help="统计信息")
    sub.add_parser("list", help="列出全部记忆")

    args = parser.parse_args(argv)
    sys_root = _system(args)

    if args.cmd == "remember":
        res = sys_root.remember(args.content, type_hint=args.type, source=args.source,
                                interactive=not args.no_interactive)
        print(json.dumps(res, ensure_ascii=False, indent=2))
    elif args.cmd == "recall":
        res = sys_root.recall(args.query, top_k=args.top_k)
        print(json.dumps(res, ensure_ascii=False, indent=2))
    elif args.cmd == "evolve":
        print(json.dumps(sys_root.evolve(), ensure_ascii=False, indent=2))
    elif args.cmd == "stats":
        print(json.dumps(sys_root.stats(), ensure_ascii=False, indent=2))
    elif args.cmd == "list":
        print(json.dumps(sys_root.list_all(), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
