import datetime as _dt
from typing import Optional

from .models import MemoryEntry, MemoryType, MemoryStatus
from .storage import Storage
from .crypto import CryptoProvider
from . import modules


class MemorySystem:
    def __init__(self, root: str, passphrase: Optional[str] = None):
        crypto = CryptoProvider(passphrase=passphrase, enabled=passphrase is not None)
        self.storage = Storage(root, crypto)

    def remember(self, content: str, type_hint: Optional[str] = None,
                 source: str = "user_input", interactive: bool = True,
                 conflict_policy: str = "ask") -> dict:
        ok, reason = modules.validate_input(content)
        if not ok:
            return {"status": "rejected", "reason": reason}

        mtype = MemoryType.from_str(type_hint) if type_hint else modules.classify(content)
        candidates = self.storage.query_by_type(mtype)

        dup = modules.find_duplicate(content, candidates)
        if dup:
            return {"status": "duplicate", "entry_id": dup.id, "content": dup.content}

        entry = MemoryEntry.create(content, mtype, source=source)

        conflicts = modules.detect_conflict(entry, candidates)
        if conflicts:
            if interactive and conflict_policy == "ask":
                decision = self._ask_conflict(entry, conflicts)
            else:
                decision = conflict_policy
            if decision == "cancel":
                return {"status": "cancelled", "conflicts": [c.id for c in conflicts]}
            if decision == "delete_existing":
                for c in conflicts:
                    self.storage.delete(c.id)
            elif decision == "merge":
                merged = conflicts[0].content + " | " + content
                conflicts[0].content = merged
                self.storage.put(conflicts[0])
                return {"status": "merged", "entry_id": conflicts[0].id}

        self.storage.put(entry)
        return {"status": "stored", "entry_id": entry.id, "type": entry.type,
                "conflicts": [c.id for c in conflicts]}

    def _ask_conflict(self, entry: MemoryEntry, conflicts: list[MemoryEntry]) -> str:
        print(f"\n[冲突检测] 新记忆与已有记忆存在潜在矛盾：")
        print(f"  新: {entry.content}")
        for c in conflicts:
            print(f"  已有({c.id}): {c.content}")
        while True:
            ans = input("  处理 [keep 保留新/delete 删旧/merge 合并/cancel 取消]: ").strip().lower()
            if ans in ("keep", "delete", "merge", "cancel", "delete_existing"):
                return "delete_existing" if ans == "delete" else ans

    def recall(self, query: str, top_k: int = 5) -> list[dict]:
        now = _dt.datetime.now(_dt.timezone.utc)
        results = modules.graded_retrieval(self.storage, query, top_k, now)
        for entry, score in results:
            entry.access_count += 1
            entry.last_accessed = now.isoformat()
            entry.priority = modules.recompute_priority(entry, now)
            self.storage.put(entry)
        return [{"id": e.id, "type": e.type, "content": e.content,
                 "priority": e.priority, "score": s} for e, s in results]

    def evolve(self) -> dict:
        return modules.evolve(self.storage)

    def stats(self) -> dict:
        return self.storage.stats()

    def list_all(self) -> list[dict]:
        return [e.to_dict() for e in self.storage.all_entries()]
