import os
import tempfile

from openclaw_memory import MemorySystem


def _new_system():
    root = tempfile.mkdtemp(prefix="ocm_test_")
    return MemorySystem(root), root


def test_remember_and_recall():
    sys_mem, _ = _new_system()
    r = sys_mem.remember("用户偏好中文技术文档，术语统一用简体", type_hint="preference")
    assert r["status"] == "stored", r

    out = sys_mem.recall("中文术语偏好")
    assert any("简体" in item["content"] for item in out), out


def test_dedup():
    sys_mem, _ = _new_system()
    sys_mem.remember("北京是中国的首都", type_hint="fact")
    r2 = sys_mem.remember("北京是中国的首都", type_hint="fact")
    assert r2["status"] == "duplicate", r2


def test_conflict_detection_non_interactive():
    sys_mem, _ = _new_system()
    sys_mem.remember("用户允许在译文中保留英文缩写", type_hint="instruction")
    r = sys_mem.remember("用户禁止在译文中保留英文缩写", type_hint="instruction",
                         interactive=False, conflict_policy="keep")
    assert r["status"] == "stored"
    assert len(r["conflicts"]) >= 1, r


def test_classify():
    sys_mem, _ = _new_system()
    r = sys_mem.remember("必须保留原文段落编号")
    assert r["status"] == "stored"
    assert sys_mem.storage.get(r["entry_id"]).type == "instruction"


def test_self_evolution_deprecates():
    import datetime as dt
    sys_mem, _ = _new_system()
    sys_mem.remember("一条很少用到的冷知识条目", type_hint="common_sense")
    eid = sys_mem.recall("冷知识")[0]["id"]
    entry = sys_mem.storage.get(eid)
    old = dt.datetime.now(dt.timezone.utc) - dt.timedelta(days=60)
    entry.last_accessed = old.isoformat()
    entry.access_count = 0
    sys_mem.storage.put(entry)
    res = sys_mem.evolve()
    assert res["deprecated"] >= 1, res


def test_encryption_roundtrip():
    root = tempfile.mkdtemp(prefix="ocm_enc_")
    sys_mem = MemorySystem(root, passphrase="secret")
    sys_mem.remember("加密存储的敏感偏好", type_hint="preference")
    path = os.path.join(root, "preference")
    files = os.listdir(path)
    with open(os.path.join(path, files[0]), "rb") as f:
        raw = f.read()
    assert "加密存储" not in raw.decode("utf-8", "ignore")
    assert sys_mem.recall("敏感偏好")


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_") and callable(fn):
            fn()
            print("PASS", name)
    print("ALL TESTS PASSED")
