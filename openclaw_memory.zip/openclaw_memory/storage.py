import json
import os
from typing import Optional

from .crypto import CryptoProvider
from .models import MemoryEntry, MemoryType, MemoryStatus


class Storage:
    def __init__(self, root: str, crypto: Optional[CryptoProvider] = None):
        self.root = root
        self.crypto = crypto or CryptoProvider(enabled=False)
        self.index_path = os.path.join(root, "meta_index.json")
        self.index: dict = {"categories": [], "entries": {}}
        self._ensure_dirs()
        self._load_index()

    def _ensure_dirs(self):
        os.makedirs(self.root, exist_ok=True)
        for t in MemoryType:
            os.makedirs(os.path.join(self.root, t.value), exist_ok=True)

    def _load_index(self):
        if os.path.exists(self.index_path):
            try:
                with open(self.index_path, "r", encoding="utf-8") as f:
                    self.index = json.load(f)
            except Exception:
                self.index = {"categories": [], "entries": {}}
        self.index.setdefault("categories", [])
        self.index.setdefault("entries", {})

    def _save_index(self):
        self.index["categories"] = [
            {
                "type": t.value,
                "path": os.path.join(self.root, t.value),
                "entry_count": sum(1 for e in self.index["entries"].values() if e["type"] == t.value),
                "updated_at": max(
                    (e["timestamp"] for e in self.index["entries"].values() if e["type"] == t.value),
                    default="",
                ),
            }
            for t in MemoryType
        ]
        with open(self.index_path, "w", encoding="utf-8") as f:
            json.dump(self.index, f, ensure_ascii=False, indent=2)

    def _entry_path(self, entry: MemoryEntry) -> str:
        return os.path.join(self.root, entry.type, entry.id + ".json")

    def put(self, entry: MemoryEntry):
        path = self._entry_path(entry)
        raw = json.dumps(entry.to_dict(), ensure_ascii=False, indent=2).encode("utf-8")
        with open(path, "wb") as f:
            f.write(self.crypto.encrypt(raw))
        self.index["entries"][entry.id] = entry.to_dict()
        self._save_index()

    def get(self, entry_id: str) -> Optional[MemoryEntry]:
        rec = self.index["entries"].get(entry_id)
        if not rec:
            return None
        return MemoryEntry.from_dict(rec)

    def delete(self, entry_id: str) -> bool:
        rec = self.index["entries"].pop(entry_id, None)
        if not rec:
            return False
        path = os.path.join(self.root, rec["type"], entry_id + ".json")
        if os.path.exists(path):
            os.remove(path)
        self._save_index()
        return True

    def all_entries(self) -> list[MemoryEntry]:
        return [MemoryEntry.from_dict(e) for e in self.index["entries"].values()]

    def query_by_type(self, mtype: MemoryType) -> list[MemoryEntry]:
        return [e for e in self.all_entries() if e.type == mtype.value]

    def stats(self) -> dict:
        entries = self.index["entries"].values()
        by_type = {}
        for e in entries:
            by_type[e["type"]] = by_type.get(e["type"], 0) + 1
        return {
            "total": len(entries),
            "by_type": by_type,
            "active": sum(1 for e in entries if e["status"] == MemoryStatus.ACTIVE.value),
            "deprecated": sum(1 for e in entries if e["status"] == MemoryStatus.DEPRECATED.value),
        }
