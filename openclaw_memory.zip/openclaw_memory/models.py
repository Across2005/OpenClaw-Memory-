from __future__ import annotations

import datetime as _dt
import uuid
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Optional


class MemoryType(str, Enum):
    COMMON_SENSE = "common_sense"
    INSTRUCTION = "instruction"
    PREFERENCE = "preference"
    FACT = "fact"
    OTHER = "other"

    @classmethod
    def from_str(cls, value: str) -> "MemoryType":
        try:
            return cls(value)
        except ValueError:
            return cls.OTHER


class MemoryStatus(str, Enum):
    ACTIVE = "active"
    DEPRECATED = "deprecated"
    ARCHIVED = "archived"


@dataclass
class MemoryEntry:
    id: str
    type: str
    content: str
    confidence: float = 0.8
    source: str = "user_input"
    timestamp: str = field(default_factory=lambda: _dt.datetime.now(_dt.timezone.utc).isoformat())
    access_count: int = 0
    priority: float = 0.5
    status: str = "active"
    last_accessed: Optional[str] = None
    feedback_score: float = 0.0
    tags: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "MemoryEntry":
        d.setdefault("tags", [])
        d.setdefault("feedback_score", 0.0)
        return cls(**d)

    @classmethod
    def create(cls, content: str, mtype: MemoryType, source: str = "user_input",
               confidence: float = 0.8, tags: Optional[list] = None) -> "MemoryEntry":
        now = _dt.datetime.now(_dt.timezone.utc).isoformat()
        return cls(
            id="mem_" + uuid.uuid4().hex[:12],
            type=mtype.value,
            content=content,
            confidence=confidence,
            source=source,
            timestamp=now,
            last_accessed=now,
            tags=tags or [],
        )
