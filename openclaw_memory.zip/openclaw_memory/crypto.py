import base64
import hashlib
import os
from typing import Optional

_USE_FERNET = False
try:
    from cryptography.fernet import Fernet  # type: ignore
    _USE_FERNET = True
except Exception:
    pass


class CryptoProvider:
    def __init__(self, passphrase: Optional[str] = None, enabled: bool = True):
        self.enabled = enabled and passphrase is not None
        self.passphrase = passphrase
        if self.enabled and _USE_FERNET:
            key = hashlib.sha256(passphrase.encode("utf-8")).digest()
            self._fernet = Fernet(base64.urlsafe_b64encode(key))

    def encrypt(self, data: bytes) -> bytes:
        if not self.enabled:
            return data
        if _USE_FERNET:
            return self._fernet.encrypt(data)
        return self._xor_obfuscate(data)

    def decrypt(self, data: bytes) -> bytes:
        if not self.enabled:
            return data
        if _USE_FERNET:
            return self._fernet.decrypt(data)
        return self._xor_obfuscate(data)

    def _xor_obfuscate(self, data: bytes) -> bytes:
        if not self.passphrase:
            return data
        key = self.passphrase.encode("utf-8")
        return bytes(b ^ key[i % len(key)] for i, b in enumerate(data))
