# Coze 代码节点脚本：本地 Agent 自进化记忆系统（纯云端原生版 / 方案 B）
#
# 部署方式（Coze 工作流）：
#   1. 在 Bot 中新建「工作流」，拖入一个「代码节点」，语言选 Python。
#   2. 将本文件全部内容粘贴进代码框。
#   3. 配置输入参数：action, content, store（以及可选 mtype, top_k）。
#   4. 配置输出参数：result, store, isSuccess（与下面 return 对象一致）。
#   5. 用一个「工作流变量」(如 memory_store) 承接本节点返回的 store，
#      并在下一次调用时把它作为 store 输入回传，实现跨轮持久记忆。
#   6. 在「开始」节点或「问答」节点后串联本节点，按 action 路由即可。
#
# 说明：Coze 代码节点仅允许单个函数且只能用标准库，因此所有逻辑内联在 main 中。

import json
import math
import re
import uuid
from datetime import datetime, timezone


async def main(args: Args) -> Output:
    params = args.params
    action = (params.get("action") or "recall").strip().lower()
    content = params.get("content") or ""
    mtype = params.get("mtype") or ""
    top_k = int(params.get("top_k") or 5)
    raw_store = params.get("store") or "{}"

    try:
        store = json.loads(raw_store) if raw_store.strip() else {}
    except Exception:
        store = {}
    store.setdefault("entries", [])

    stop = set("的 了 是 在 和 与 及 对 把 被 我 你 他 她 它 们 这 那 有 个 不 也 都 就 而 等 以 为 其 此".split())

    def tok(text):
        text = text.lower()
        latin = re.findall(r"[a-z0-9]+", text)
        cjk = re.findall(r"[\u4e00-\u9fff]", text)
        return [t for t in latin if t not in stop] + cjk

    def embed(text):
        from collections import Counter
        return Counter(tok(text))

    def cos(a, b):
        if not a or not b:
            return 0.0
        common = set(a) & set(b)
        if not common:
            return 0.0
        dot = sum(a[t] * b[t] for t in common)
        na = sum(v * v for v in a.values()) ** 0.5
        nb = sum(v * v for v in b.values()) ** 0.5
        return dot / (na * nb) if na and nb else 0.0

    def sim(a, b):
        return cos(embed(a), embed(b))

    def now_iso():
        return datetime.now(timezone.utc).isoformat()

    def age_days(iso):
        if not iso:
            return 9999.0
        try:
            ts = datetime.fromisoformat(iso)
            if ts.tzinfo is None:
                ts = ts.replace(tzinfo=timezone.utc)
            return max((datetime.now(timezone.utc) - ts).total_seconds() / 86400.0, 0.0)
        except Exception:
            return 9999.0

    def classify(text):
        kw = {
            "instruction": ["必须", "不要", "禁止", "总是", "务必", "指令", "规则", "不允许", "要求", "应当"],
            "preference": ["偏好", "喜欢", "习惯", "倾向", "更愿意", "风格", "口味"],
            "fact": ["成立于", "位于", "定义", "数据", "统计", "出生于", "总部", "发布于", "创始于"],
        }
        scores = {k: 0 for k in kw}
        for k, ws in kw.items():
            for w in ws:
                if w in text:
                    scores[k] += 1
        best = max(scores, key=lambda k: scores[k])
        return best if scores[best] > 0 else "common_sense"

    def priority_of(e):
        freq = min(e.get("access_count", 0) / 20.0, 1.0)
        recency = 0.5 ** (age_days(e.get("last_accessed")) / 30.0)
        fb = e.get("feedback_score", 0.0)
        fbn = (max(-1.0, min(1.0, fb)) + 1.0) / 2.0 if fb != 0.0 else 0.0
        return round(0.5 * freq + 0.3 * recency + 0.2 * fbn, 4)

    polarity = [("支持", "反对"), ("是", "不是"), ("允许", "禁止"),
                ("喜欢", "讨厌"), ("正确", "错误"), ("启用", "禁用")]

    def has_opposite(a, b):
        for p, n in polarity:
            if (p in a and n in b) or (n in a and p in b):
                return True
        return False

    result = {}
    if action == "remember":
        if not content or len(content.strip()) < 4:
            ret = {"result": "拒绝：内容过短或为空", "store": json.dumps(store, ensure_ascii=False), "isSuccess": True}
            return ret
        t = mtype if mtype else classify(content)
        cands = [e for e in store["entries"] if e["type"] == t]
        dup = None
        best_sim = 0.0
        for c in cands:
            s = sim(content, c["content"])
            if s > best_sim:
                best_sim, dup = s, c
        if dup and best_sim >= 0.92:
            ret = {"result": "已存在相似记忆，跳过：" + dup["content"],
                   "store": json.dumps(store, ensure_ascii=False), "isSuccess": True}
            return ret
        conflicts = [c["id"] for c in cands if sim(content, c["content"]) >= 0.55
                     and has_opposite(content, c["content"])]
        entry = {
            "id": "mem_" + uuid.uuid4().hex[:12],
            "type": t,
            "content": content,
            "confidence": 0.8,
            "source": "user_input",
            "timestamp": now_iso(),
            "access_count": 0,
            "priority": 0.5,
            "status": "active",
            "last_accessed": now_iso(),
            "feedback_score": 0.0,
            "conflicts": conflicts,
        }
        store["entries"].append(entry)
        result = {"status": "stored", "entry_id": entry["id"], "type": t, "conflicts": conflicts}

    elif action == "recall":
        scored = []
        for e in store["entries"]:
            if e.get("status") != "active":
                continue
            s = sim(content, e["content"])
            if s <= 0:
                continue
            age = age_days(e.get("last_accessed"))
            recency = 0.5 ** (age / 30.0)
            score = s * e.get("priority", 0.5) * (0.5 + 0.5 * recency)
            scored.append((score, e))
            e["access_count"] = e.get("access_count", 0) + 1
            e["last_accessed"] = now_iso()
            e["priority"] = priority_of(e)
        scored.sort(key=lambda x: x[0], reverse=True)
        result = [{"id": e["id"], "type": e["type"], "content": e["content"],
                   "priority": e["priority"], "score": round(sc, 4)}
                  for sc, e in scored[:top_k]]

    elif action == "evolve":
        deprecated = 0
        for e in store["entries"]:
            if e.get("status") == "archived":
                continue
            e["priority"] = priority_of(e)
            if e["priority"] < 0.15 and age_days(e.get("last_accessed")) > 30:
                e["status"] = "deprecated"
                deprecated += 1
        result = {"recomputed": len(store["entries"]), "deprecated": deprecated}

    elif action == "stats":
        by_type = {}
        for e in store["entries"]:
            by_type[e["type"]] = by_type.get(e["type"], 0) + 1
        result = {"total": len(store["entries"]), "by_type": by_type,
                  "active": sum(1 for e in store["entries"] if e.get("status") == "active"),
                  "deprecated": sum(1 for e in store["entries"] if e.get("status") == "deprecated")}
    else:
        result = {"error": "未知 action：" + action}

    ret = {
        "result": json.dumps(result, ensure_ascii=False),
        "store": json.dumps(store, ensure_ascii=False),
        "isSuccess": True,
    }
    return ret
