# Coze 部署：OpenClaw 自进化记忆 Skill

提供两种在 Coze（coze.cn）上直接跑起来的方式，对应项目说明报告中的方案 B（纯云端）与方案 A（本地优先）。

## 方式一：纯云端代码节点（推荐参赛，零服务器）

1. 打开 Bot → 工作流 → 新建，拖入「代码节点」，语言选 **Python**。
2. 将 `memory_code_node.py` 的**全部内容**粘贴进代码框。
3. 输入参数（与代码 `args.params` 对应）：
   - `action`：`remember` / `recall` / `evolve` / `stats`
   - `content`：记忆原文或检索问句
   - `store`：记忆库 JSON 字符串（用「工作流变量」`memory_store` 承接并回传）
   - 可选：`mtype`（强制类型）、`top_k`
4. 输出参数：`result`、`store`、`isSuccess`。
5. 新建变量 `memory_store`（初始值 `{}`），连成「开始 → 代码节点 → 结束」，把节点返回 `store` 写回变量，下一轮再作为输入，即可跨轮持久记忆。
6. 在「人设与回复逻辑」中引用该工作流，或用「选择器/意图」按 action 路由。

> 该脚本纯标准库、单函数，完全契合 Coze 代码节点约束（Python 3.11，仅 `requests_async`/`numpy` 额外可用）。

## 方式二：API 插件（本地优先，真·私有）

1. 安装依赖：`pip install fastapi uvicorn`
2. 启动后端：`python backend_server.py`（默认 `http://127.0.0.1:8000`，可用 `OPENCLAW_MEMORY_ROOT` 指定存储目录，`OPENCLAW_MEMORY_PASSPHRASE` 启用加密）
3. 若仅本地测试，用内网穿透/部署到公网得到 HTTPS 地址。
4. 在 Coze「插件 → 创建插件 → 通过 OpenAPI 创建」，上传 `plugin_openapi.yaml`，把 `servers.url` 改成你的公网地址。
5. 在 Bot 中「添加插件 → OpenClaw Memory Skill」，即可像调用工具一样使用 remember/recall/evolve/stats。

## 文件清单
- `memory_code_node.py` — Coze 代码节点脚本（方式一）
- `backend_server.py` — FastAPI 后端（方式二）
- `plugin_openapi.yaml` — Coze 插件 OpenAPI 描述（方式二）
- `skill.md` — 技能元信息与说明，可导入为 Agent 技能

## 与本地原型的区别
方式二复用了 `openclaw_memory/`（见《实现落地与可行性扩展》）同一套引擎；方式一把核心算法内联进 Coze 云端运行，二者行为一致，便于在本地原型上先验证、再上 Coze。
