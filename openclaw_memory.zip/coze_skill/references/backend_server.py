"""Coze 插件后端：把本地自进化记忆引擎暴露为 HTTP API。

部署（任选其一）：
  - 本地：pip install fastapi uvicorn；python backend_server.py；访问 http://127.0.0.1:8000
  - 云端：部署到任意支持 FastAPI 的平台（如火山引擎/云函数），得到公网 URL。
在 Coze 中「添加插件 → 通过 OpenAPI 创建」，上传同目录 plugin_openapi.yaml，
将 servers.url 改为你的公网地址即可作为技能调用。

对应方案 A 思路：Coze 作编排/交互层，记忆落盘到本服务（本地优先）。
"""
from __future__ import annotations

import os
import uvicorn
from fastapi import FastAPI, Query
from fastapi.middleware.cors import CORSMiddleware

from openclaw_memory import MemorySystem

ROOT = os.environ.get("OPENCLAW_MEMORY_ROOT", os.path.join(os.getcwd(), "memory"))
PASSPHRASE = os.environ.get("OPENCLAW_MEMORY_PASSPHRASE")
sys_mem = MemorySystem(ROOT, passphrase=PASSPHRASE)

app = FastAPI(title="OpenClaw Memory Skill", version="0.1.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


@app.post("/remember")
def remember(content: str, mtype: str = "", source: str = "user_input",
             interactive: bool = False, conflict_policy: str = "keep"):
    res = sys_mem.remember(content, type_hint=mtype or None, source=source,
                           interactive=interactive, conflict_policy=conflict_policy)
    return res


@app.post("/recall")
def recall(query: str, top_k: int = 5):
    return sys_mem.recall(query, top_k=top_k)


@app.post("/evolve")
def evolve():
    return sys_mem.evolve()


@app.get("/stats")
def stats():
    return sys_mem.stats()


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=int(os.environ.get("PORT", 8000)))
